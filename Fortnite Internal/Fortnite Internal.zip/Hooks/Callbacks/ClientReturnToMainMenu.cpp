#include "../Hooks.h"

// Original function pointer
typedef void(*ClientReturnToMainMenu_t)();
ClientReturnToMainMenu_t oClientReturnToMainMenu = nullptr;

// Hook function
void __fastcall hkClientReturnToMainMenu() {
    // nulled to prevent user from getting disconnected
    return;
}